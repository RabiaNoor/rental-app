// ignore_for_file: prefer_const_constructors
import 'package:flutter/material.dart';
import '../../../themes/colors.dart';
import '../../../themes/config_files/screen_size_config.dart';
import '../../../themes/config_files/values.dart';
import '../widgets/appbar.dart';
import '../widgets/button_group.dart';
import '../widgets/card_Horizontal_List.dart';
import '../widgets/card_vertical_list.dart';
import '../widgets/search_and_filter.dart';
import '../widgets/title_bar.dart';

class ScreenHome extends StatelessWidget {
  const ScreenHome({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    ScreenConfig().init(context);

    return Scaffold(
      backgroundColor: kColorScaffold,
      appBar: appbar__widget(),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              SearchAndFilter(),
              ButtonGroup__widget(),
              kSizedBoxHeight_8,
              TitleBar__widget(title: 'Near from you', ontap: () {}),
              CardHorizontalList__widget(),
              kSizedBoxHeight_8,
              TitleBar__widget(title: 'Best for you', ontap: () {}),
              CaerdVerticalList__widget(),
              kSizedBoxHeight_16,
            ],
          ),
        ),
      ),
    );
  }
}
