// ignore: file_names
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:another_flushbar/flushbar.dart';
import '../../../services/auth_services.dart';
import '../Login/login.dart';
import '../home/view/home.dart';

class RegScreen extends StatefulWidget {
  const RegScreen({Key? key}) : super(key: key);

  @override
  State<RegScreen> createState() => _RegScreenState();
}

class _RegScreenState extends State<RegScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool submit = true;
  bool obscure = true;
  bool isLoading = false;
    void _saveUserData() {
    String name = _nameController.text;
    String email = _emailController.text;
    String password = _passwordController.text;


    CollectionReference usersCollection =
        FirebaseFirestore.instance.collection('UserCollection');
    DocumentReference newUserDoc = usersCollection.doc();
// FIREBASE COLLECTION MAIN DATA SAVE 
    newUserDoc.set({
      "name": name,
      "email": email,
      "password": password,
    }).then((_) {
      print("User data saved to Firestore");
    }).catchError((error) {
      print("Error saving user data: $error");
    });
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
          children: [
            Container(
              height: double.infinity,
              width: double.infinity,
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [
                  Color(0xffB81736),
                  Color(0xff281537),
                ]),
              ),
              child: const Padding(
                padding: EdgeInsets.only(top: 60.0, left: 22),
                child: Text(
                  'Create Your\nAccount',
                  style: TextStyle(
                      fontSize: 30,
                      color: Colors.white,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 170.0),
              child: Container(
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(40), topRight: Radius.circular(40)),
                  color: Colors.white,
                ),
                height: double.infinity,
                width: double.infinity,
                child:  Padding(
                  padding: const EdgeInsets.only(left: 18.0,right: 18),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        TextField(
                          controller: _nameController,
                          decoration: const InputDecoration(
                              suffixIcon: Icon(Icons.check,color: Colors.grey,),
                              label: Text('Full Name',style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color:Color(0xffB81736),
                              ),)
                          ),
                        ),
                         TextField(
                          controller: _emailController,
                          decoration: const InputDecoration(
                              suffixIcon: Icon(Icons.check,color: Colors.grey,),
                              label: Text('Enter your Gmail',style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color:Color(0xffB81736),
                              ),)
                          ),
                        ),
                        TextField(
                          controller: _passwordController,
                          obscureText: true,
                          decoration: const InputDecoration(
                              suffixIcon: Icon(Icons.visibility_off,color: Colors.grey,),
                              label: Text('Password',style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color:Color(0xffB81736),
                              ),)
                          ),
                        ),
                        const TextField(
                          obscureText: true,
                          decoration: InputDecoration(
                              suffixIcon: Icon(Icons.visibility_off,color: Colors.grey,),
                              label: Text('Conform Password',style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color:Color(0xffB81736),
                              ),)
                          ),
                        ),
                         SizedBox(height: 30,),
                        GestureDetector(
                          onTap: ()  {
                            if (_formKey.currentState!.validate()) {
                              setState(() {
                                submit = false;
                                isLoading = true;
                              });
                              Future.delayed(Duration(seconds: 3), () async {
                                await    FirebaseAuth.instance.createUserWithEmailAndPassword(email: _emailController.text.trim(), password: _passwordController.text.trim())
                                    .whenComplete(() => setState(() {
                                  isLoading = false;
                                  submit = true;
                                }));
                              });
                              Flushbar(
                                isDismissible: true,
                                dismissDirection: FlushbarDismissDirection.HORIZONTAL,
                                icon: Icon(
                                  Icons.error,
                                  color: Colors.white,
                                  size: 30,
                                ),
                                mainButton: ButtonBar(
                                  children: [
                                    GestureDetector(
                                      onTap: () {
                                        print("You clicked me!");
                                      },
                                      child: Icon(
                                        Icons.cancel_outlined,
                                        color: Colors.white,
                                        size: 30,
                                      ),
                                    )
                                  ],
                                ),
                                backgroundColor: Colors.green,
                                duration: Duration(seconds: 2),
                                message: "Register SuccessFully",
                                messageSize: 10,
                                titleText: Text("Error",
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white)),
                              )..show(context);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => const ScreenHome()),
                              );


                            }
                            else{ Flushbar(
                              isDismissible: true,
                              dismissDirection: FlushbarDismissDirection.HORIZONTAL,
                              icon: Icon(
                                Icons.error,
                                color: Colors.white,
                                size: 30,
                              ),
                              mainButton: ButtonBar(
                                children: [
                                  GestureDetector(
                                    onTap: () {
                                      print("You clicked me!");
                                    },
                                    child: Icon(
                                      Icons.cancel_outlined,
                                      color: Colors.white,
                                      size: 30,
                                    ),
                                  )
                                ],
                              ),
                              backgroundColor: Colors.red,
                              duration: Duration(seconds: 2),
                              message: "Register Failed",
                              messageSize: 10,
                              titleText: Text("Error",
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white)),
                            )..show(context);}
                          },
                          child: Container(
                            height: 55,
                            width: 300,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(30),
                              gradient: const LinearGradient(
                                  colors: [
                                    Color(0xffB81736),
                                    Color(0xff281537),
                                  ]
                              ),
                            ),
                            child:  isLoading
                                ? const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  "Please wait....",
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.white,
                                  ),
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                CircularProgressIndicator(
                                  color: Colors.white,
                                ),
                              ],
                            )
                                :Center(child: Text('SIGN UP',style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                                color: Colors.white
                            ),),),
                          ),
                        ),
                        const SizedBox(height: 20,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Divider(
                          color: Colors.black,
                          height: 5,
                          thickness: 3,
                        ),
                        const Text('or continue with'),
                        Divider(
                          thickness: 1,
                          color: Colors.grey[400],
                        ),
                      ],
                    ),
                    InkWell(child: Container(
                      height: 55,
                      width: 300,
                      margin: const EdgeInsets.only(top: 20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        color: Colors.black,
                      ),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              height: 40,
                              width: 30,
                              decoration: const BoxDecoration(
                                image: DecorationImage(image: AssetImage('assets/icons/google.png'),
                                fit: BoxFit.cover
                                ),
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 10,),
                            const Text('Sign Up with Google',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold,color: Colors.white,),)
                          ],
                        ),
                      ),
                    ),
                    onTap: () async{
                      AuthServices().signInWithGoogle();
                    },
                    ),
                      const SizedBox(height: 10,),
                        Align(
                          alignment: Alignment.bottomRight,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              const Text("Already have account!",style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.grey
                              ),),
                              TextButton(onPressed: (){Navigator.push(context, MaterialPageRoute(builder: (context)=> const loginScreen()));},
                                child: isLoading
                                    ? const Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(
                                      "Please wait....",
                                      style: TextStyle(
                                        fontSize: 20,
                                        color: Colors.white,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    CircularProgressIndicator(
                                      color: Colors.white,
                                    ),
                                  ],
                                )
                                    :Center(
                                      child: Text("Sign In",style: TextStyle(///done login page
                                  fontWeight: FontWeight.bold,
                                  fontSize: 17,
                                  color: Colors.black
                              ),),
                                    ),),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ));
  }
}

