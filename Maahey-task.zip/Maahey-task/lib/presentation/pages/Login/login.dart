import 'package:another_flushbar/flushbar.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../../../services/auth_services.dart';
import '../Register/reg_Screen.dart';
import '../home/view/home.dart';

// ignore: camel_case_types
class loginScreen extends StatefulWidget {
  const loginScreen({Key? key}) : super(key: key);

  @override
  State<loginScreen> createState() => _loginScreenState();
}

// ignore: camel_case_types
class _loginScreenState extends State<loginScreen> {
  final TextEditingController _email = TextEditingController();
  final TextEditingController _password = TextEditingController();
  bool passToggle = true;
  final _formKey = GlobalKey<FormState>();
  bool submit = true;
  bool obscure = true;
    void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 2),
      ),
    );
  }
  bool isLoading = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
      children: [
        Container(
          height: double.infinity,
          width: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [
              Color(0xffB81736),
              Color(0xff281537),
            ]),
          ),
          child: const Padding(
            padding: EdgeInsets.only(top: 60.0, left: 22),
            child: Text(
              'Hello\nSign in!',
              style: TextStyle(
                  fontSize: 30,
                  color: Colors.white,
                  fontWeight: FontWeight.bold),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 200.0),
          child: Container(
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(40), topRight: Radius.circular(40)),
              color: Colors.white,
            ),
            height: double.infinity,
            width: double.infinity,
            child:  Padding(
              padding: const EdgeInsets.only(left: 18.0,right: 18),
              child: Form(
                key: _formKey,
                child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextField(
                      controller: _email,
                      decoration: const InputDecoration(
                        suffixIcon: Icon(Icons.check,color: Colors.grey,),
                        label: Text('Gmail',style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color:Color(0xffB81736),
                        ),)
                      ),
                    ),
                    TextField(
                      controller: _password,
                      obscureText: passToggle,
                      decoration: InputDecoration(
                          suffixIcon: const Icon(Icons.visibility_off,color: Colors.grey,),
                          label: const Text('Password',style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color:Color(0xffB81736),
                          ),
                          ),
                          suffix: InkWell(
                        onTap: () {
                          setState(() {
                            passToggle = !passToggle;
                          });
                        },
                        child: Icon(
                            passToggle ? Icons.visibility : Icons.visibility_off),
                      ),
                      ),
                    ),
                    const SizedBox(height: 20,),
                    const Align(
                      alignment: Alignment.centerRight,
                      child: Text('Forgot Password?',style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 17,
                        color: Color(0xff281537),
                      ),),
                    ),
                    const SizedBox(height: 30,),
                    GestureDetector(
                      onTap: (){
                        if (_formKey.currentState!.validate()) {
                          setState(() {
                            submit = false;
                            isLoading = true;
                          });
                          Future.delayed(Duration(seconds: 3), () async {
                            await  FirebaseAuth.instance
                                .signInWithEmailAndPassword(
                                email: _email.text.trim(), password: _password.text.trim())
                                .whenComplete(() => setState(() {
                              isLoading = false;
                              submit = true;
                            }));
                          });
                          Flushbar(
                            isDismissible: true,
                            dismissDirection: FlushbarDismissDirection.HORIZONTAL,
                            icon: Icon(
                              Icons.error,
                              color: Colors.white,
                              size: 30,
                            ),
                            mainButton: ButtonBar(
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    print("You clicked me!");
                                  },
                                  child: Icon(
                                    Icons.cancel_outlined,
                                    color: Colors.white,
                                    size: 30,
                                  ),
                                )
                              ],
                            ),
                            backgroundColor: Colors.green,
                            duration: Duration(seconds: 2),
                            message: "Login SuccessFully",
                            messageSize: 10,
                            titleText: Text("Error",
                                style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white)),
                          )..show(context);
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const ScreenHome(),
                            ),
                          );

                        }
                        else{ Flushbar(
                          isDismissible: true,
                          dismissDirection: FlushbarDismissDirection.HORIZONTAL,
                          icon: Icon(
                            Icons.error,
                            color: Colors.white,
                            size: 30,
                          ),
                          mainButton: ButtonBar(
                            children: [
                              GestureDetector(
                                onTap: () {
                                  print("You clicked me!");
                                },
                                child: Icon(
                                  Icons.cancel_outlined,
                                  color: Colors.white,
                                  size: 30,
                                ),
                              )
                            ],
                          ),
                          backgroundColor: Colors.red,
                          duration: Duration(seconds: 2),
                          message: "Login Failed",
                          messageSize: 10,
                          titleText: Text("Error",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white)),
                        )..show(context);}
                      },
                      child: Container(
                        height: 55,
                        width: 300,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(30),
                          gradient: const LinearGradient(
                            colors: [
                              Color(0xffB81736),
                              Color(0xff281537),
                            ]
                          ),
                        ),
                        child: isLoading
                            ? const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              "Please wait....",
                              style: TextStyle(
                                fontSize: 20,
                                color: Colors.white,
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            CircularProgressIndicator(
                              color: Colors.white,
                            ),
                          ],
                        )
                        :Center(
                          child: Text('SIGN IN',style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: Colors.white
                          ),),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Divider(
                          color: Colors.black,
                          height: 5,
                          thickness: 3,
                        ),
                        const Text('or continue with'),
                        Divider(
                          thickness: 1,
                          color: Colors.grey[400],
                        ),
                      ],
                    ),
                    InkWell(child: Container(
                      height: 55,
                      width: 300,
                      margin: const EdgeInsets.only(top: 20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        color: Colors.black,
                      ),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              height: 40,
                              width: 30,
                              decoration: const BoxDecoration(
                                image: DecorationImage(image: AssetImage('assets/icons/google.png'),
                                fit: BoxFit.cover
                                ),
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 10,),
                            const Text('Sign In with Google',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold,color: Colors.white,),)
                          ],
                        ),
                      ),
                    ),
                    onTap: () async{
                      AuthServices().signInWithGoogle();
                    },
                    ),
                    const SizedBox(height: 30,),
                     Align(
                      alignment: Alignment.bottomRight,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          const Text("Don't have account?",style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.grey
                          ),),
                          TextButton(onPressed: (){Navigator.push(context, MaterialPageRoute(builder: (context)=> const RegScreen()));}, 
                          child: const Text('Sign Up',style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 17,
                              color: Colors.black),),),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    ));
  }
}