// import 'package:flutter/material.dart';

// ThemeData themeData(BuildContext context) {
//   return ThemeData(
//     scaffoldBackgroundColor: Colors.white,
//     appBarTheme: const AppBarTheme(color: Colors.transparent, elevation: 0),
//     colorScheme: ColorScheme.fromSwatch(
//       primarySwatch: Colors.indigo,
//     ).copyWith(secondary: Colors.amber),
//     cardTheme: const CardTheme(
//       color: kSurfaceColorLight,
//       elevation: 0,
//       // shadowColor: kShadowColor,
//     ),
//     textTheme: TextTheme(
//       bodyText2: kBodyText2Light,
//       subtitle1: kSubtitle1Light,
//       headlineLarge: kHeadlineLargeLight,
//     ),
//   );
// }

// ThemeData themeDataDark(BuildContext context) {
//   return ThemeData(
//     scaffoldBackgroundColor: const Color(0xff0A0E0F),
//     appBarTheme: const AppBarTheme(color: Colors.transparent, elevation: 0),
//     colorScheme: ColorScheme.fromSwatch(
//       primarySwatch: Colors.indigo,
//     ).copyWith(secondary: Colors.amber),
//     cardTheme: const CardTheme(
//       color: kSurfaceColorDark,
//       elevation: 0,
//       // shadowColor: kShadowColor,
//     ),
//     textTheme: TextTheme(
//       bodyText2: kBodyText2Dark,
//       subtitle1: kSubtitle1Dark,
//       headlineLarge: kHeadlineLargeDark,
//     ),
//   );
// }
