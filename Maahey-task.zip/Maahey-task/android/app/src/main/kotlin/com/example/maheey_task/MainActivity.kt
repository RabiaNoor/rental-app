package com.example.far_home

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
